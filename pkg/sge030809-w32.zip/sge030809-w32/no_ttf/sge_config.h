/* SGE Config header (generated automatically) */
#define SGE_VER 030809
#define _SGE_C_AND_CPP
#define _SGE_NOTTF
